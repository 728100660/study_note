create
    definer = root@`%` function nextval(seq_name varchar(200)) returns int
begin
    declare value Integer;
    set value = 0;
    update sequence s set value = s.value + s.increment where name = seq_name;
    select s.value into value from sequence s where s.name = seq_name;
    return value;
end;

