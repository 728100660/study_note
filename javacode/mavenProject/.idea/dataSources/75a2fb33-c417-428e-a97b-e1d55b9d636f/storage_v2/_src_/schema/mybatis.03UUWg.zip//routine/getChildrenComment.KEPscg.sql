create
    definer = root@`%` function getChildrenComment(commentId int) returns varchar(4000)
begin
    declare cTmp varchar(4000);
    declare cTmpChild varchar(4000);

    set cTmp = '';
    set cTmpChild = cast(commentId as char);

    while cTmpChild is not null
        do
            set cTmp = concat(cTmp, ',', cTmpChild);
            select group_concat(id)
            into cTmpChild
            from mybatis.comments cmt
            where find_in_set(cmt.superior_comment_id, cTmpChild)
              and (is_delete = 0 or is_delete is null);
        end while;
    return cTmp;
end;

