create
    definer = root@`%` function currval(seq_name varchar(200)) returns int
begin
    declare value Integer;
    set value = 0;
    select s.value into value from sequence s where name = seq_name;
    return value;
end;

